'use strict';


customElements.define('compodoc-menu', class extends HTMLElement {
    constructor() {
        super();
        this.isNormalMode = this.getAttribute('mode') === 'normal';
    }

    connectedCallback() {
        this.render(this.isNormalMode);
    }

    render(isNormalMode) {
        let tp = lithtml.html(`
        <nav>
            <ul class="list">
                <li class="title">
                    <a href="index.html" data-type="index-link">Open Forest Data - Agregator Frontend</a>
                </li>

                <li class="divider"></li>
                ${ isNormalMode ? `<div id="book-search-input" role="search"><input type="text" placeholder="Type to search"></div>` : '' }
                <li class="chapter">
                    <a data-type="chapter-link" href="index.html"><span class="icon ion-ios-home"></span>Getting started</a>
                    <ul class="links">
                        <li class="link">
                            <a href="overview.html" data-type="chapter-link">
                                <span class="icon ion-ios-keypad"></span>Overview
                            </a>
                        </li>
                        <li class="link">
                            <a href="index.html" data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>README
                            </a>
                        </li>
                        <li class="link">
                            <a href="changelog.html"  data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>CHANGELOG
                            </a>
                        </li>
                                <li class="link">
                                    <a href="dependencies.html" data-type="chapter-link">
                                        <span class="icon ion-ios-list"></span>Dependencies
                                    </a>
                                </li>
                    </ul>
                </li>
                    <li class="chapter modules">
                        <a data-type="chapter-link" href="modules.html">
                            <div class="menu-toggler linked" data-toggle="collapse" ${ isNormalMode ?
                                'data-target="#modules-links"' : 'data-target="#xs-modules-links"' }>
                                <span class="icon ion-ios-archive"></span>
                                <span class="link-name">Modules</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                        </a>
                        <ul class="links collapse " ${ isNormalMode ? 'id="modules-links"' : 'id="xs-modules-links"' }>
                            <li class="link">
                                <a href="modules/AppModule.html" data-type="entity-link">AppModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-AppModule-d5c2584759ef29a20520022552659349"' : 'data-target="#xs-components-links-module-AppModule-d5c2584759ef29a20520022552659349"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-AppModule-d5c2584759ef29a20520022552659349"' :
                                            'id="xs-components-links-module-AppModule-d5c2584759ef29a20520022552659349"' }>
                                            <li class="link">
                                                <a href="components/AdminLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AdminLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BackToTopComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BackToTopComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterLogoComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterLogoComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderActionsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderActionsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderControlsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderControlsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MainLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MainLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotFoundComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotFoundComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-AppModule-d5c2584759ef29a20520022552659349"' : 'data-target="#xs-injectables-links-module-AppModule-d5c2584759ef29a20520022552659349"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-AppModule-d5c2584759ef29a20520022552659349"' :
                                        'id="xs-injectables-links-module-AppModule-d5c2584759ef29a20520022552659349"' }>
                                        <li class="link">
                                            <a href="injectables/AppConfigService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>AppConfigService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/AppRoutingModule.html" data-type="entity-link">AppRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/AppServerModule.html" data-type="entity-link">AppServerModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-AppServerModule-7035cde4942c3e883baa94c9df891a6d"' : 'data-target="#xs-components-links-module-AppServerModule-7035cde4942c3e883baa94c9df891a6d"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-AppServerModule-7035cde4942c3e883baa94c9df891a6d"' :
                                            'id="xs-components-links-module-AppServerModule-7035cde4942c3e883baa94c9df891a6d"' }>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/BlogModule.html" data-type="entity-link">BlogModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-BlogModule-b1e7098041c579adbb8827874f95df07"' : 'data-target="#xs-components-links-module-BlogModule-b1e7098041c579adbb8827874f95df07"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-BlogModule-b1e7098041c579adbb8827874f95df07"' :
                                            'id="xs-components-links-module-BlogModule-b1e7098041c579adbb8827874f95df07"' }>
                                            <li class="link">
                                                <a href="components/AdminLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AdminLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BackToTopComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BackToTopComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterLogoComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterLogoComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderActionsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderActionsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderControlsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderControlsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MainLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MainLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotFoundComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotFoundComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/BlogRoutingModule.html" data-type="entity-link">BlogRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/DatasetModule.html" data-type="entity-link">DatasetModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-DatasetModule-2bd6f4e67c6a9f089fb7e19a139d4f88"' : 'data-target="#xs-components-links-module-DatasetModule-2bd6f4e67c6a9f089fb7e19a139d4f88"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-DatasetModule-2bd6f4e67c6a9f089fb7e19a139d4f88"' :
                                            'id="xs-components-links-module-DatasetModule-2bd6f4e67c6a9f089fb7e19a139d4f88"' }>
                                            <li class="link">
                                                <a href="components/DatasetComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/DatasetRoutingModule.html" data-type="entity-link">DatasetRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/DatasetsModule.html" data-type="entity-link">DatasetsModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-DatasetsModule-d6e661e4e7e9cc7e1787d94da5e1f877"' : 'data-target="#xs-components-links-module-DatasetsModule-d6e661e4e7e9cc7e1787d94da5e1f877"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-DatasetsModule-d6e661e4e7e9cc7e1787d94da5e1f877"' :
                                            'id="xs-components-links-module-DatasetsModule-d6e661e4e7e9cc7e1787d94da5e1f877"' }>
                                            <li class="link">
                                                <a href="components/DatasetsActiveFiltersComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsActiveFiltersComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsCategoryComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsCategoryComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsCategoryDescriptionComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsCategoryDescriptionComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsDataPresentationComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsDataPresentationComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsFilterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsFilterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsFiltersComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsFiltersComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsGalleryComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsGalleryComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsHeaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsHeaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsInputTagComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsInputTagComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsListComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsListComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsMapComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsMapComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsRangeComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsRangeComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsTableComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsTableComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatasetsTimeRangeComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatasetsTimeRangeComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/DatasetsRoutingModule.html" data-type="entity-link">DatasetsRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/GenericModule.html" data-type="entity-link">GenericModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-GenericModule-3ec88b3f0038ffa4c306b9840e5d9e11"' : 'data-target="#xs-components-links-module-GenericModule-3ec88b3f0038ffa4c306b9840e5d9e11"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-GenericModule-3ec88b3f0038ffa4c306b9840e5d9e11"' :
                                            'id="xs-components-links-module-GenericModule-3ec88b3f0038ffa4c306b9840e5d9e11"' }>
                                            <li class="link">
                                                <a href="components/AdminLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AdminLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BackToTopComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BackToTopComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterLogoComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterLogoComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderActionsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderActionsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderControlsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderControlsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MainLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MainLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotFoundComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotFoundComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/GenericRoutingModule.html" data-type="entity-link">GenericRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/HomeModule.html" data-type="entity-link">HomeModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-HomeModule-a4fb46dca79305938715d59feae66f9c"' : 'data-target="#xs-components-links-module-HomeModule-a4fb46dca79305938715d59feae66f9c"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-HomeModule-a4fb46dca79305938715d59feae66f9c"' :
                                            'id="xs-components-links-module-HomeModule-a4fb46dca79305938715d59feae66f9c"' }>
                                            <li class="link">
                                                <a href="components/AdminLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AdminLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BackToTopComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BackToTopComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterLogoComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterLogoComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderActionsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderActionsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderControlsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderControlsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MainLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MainLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotFoundComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotFoundComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-HomeModule-a4fb46dca79305938715d59feae66f9c"' : 'data-target="#xs-injectables-links-module-HomeModule-a4fb46dca79305938715d59feae66f9c"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-HomeModule-a4fb46dca79305938715d59feae66f9c"' :
                                        'id="xs-injectables-links-module-HomeModule-a4fb46dca79305938715d59feae66f9c"' }>
                                        <li class="link">
                                            <a href="injectables/HomeService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>HomeService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/HomeRoutingModule.html" data-type="entity-link">HomeRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/NewsModule.html" data-type="entity-link">NewsModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-NewsModule-598f6d23861090e1f8449bf595f82069"' : 'data-target="#xs-components-links-module-NewsModule-598f6d23861090e1f8449bf595f82069"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-NewsModule-598f6d23861090e1f8449bf595f82069"' :
                                            'id="xs-components-links-module-NewsModule-598f6d23861090e1f8449bf595f82069"' }>
                                            <li class="link">
                                                <a href="components/AdminLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AdminLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BackToTopComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BackToTopComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterLogoComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterLogoComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderActionsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderActionsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderControlsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderControlsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MainLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MainLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotFoundComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotFoundComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/NewsRoutingModule.html" data-type="entity-link">NewsRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/ResourceModule.html" data-type="entity-link">ResourceModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-ResourceModule-f1cdca1947090e6665be5da077640150"' : 'data-target="#xs-components-links-module-ResourceModule-f1cdca1947090e6665be5da077640150"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-ResourceModule-f1cdca1947090e6665be5da077640150"' :
                                            'id="xs-components-links-module-ResourceModule-f1cdca1947090e6665be5da077640150"' }>
                                            <li class="link">
                                                <a href="components/DocsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DocsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/IframeComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">IframeComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/JsonComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">JsonComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MapComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MapComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotSupportedComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotSupportedComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/PdfComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">PdfComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ResourceComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ResourceComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/TableComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">TableComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/TextComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">TextComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/XmlComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">XmlComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/ResourceRoutingModule.html" data-type="entity-link">ResourceRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/ServicesModule.html" data-type="entity-link">ServicesModule</a>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-ServicesModule-e4e25b83851fd7ceafa952ec7c86c31d"' : 'data-target="#xs-injectables-links-module-ServicesModule-e4e25b83851fd7ceafa952ec7c86c31d"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-ServicesModule-e4e25b83851fd7ceafa952ec7c86c31d"' :
                                        'id="xs-injectables-links-module-ServicesModule-e4e25b83851fd7ceafa952ec7c86c31d"' }>
                                        <li class="link">
                                            <a href="injectables/LanguageService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>LanguageService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/SharedModule.html" data-type="entity-link">SharedModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-SharedModule-5a49dc75cc67d1539e88d8e844c18bd1"' : 'data-target="#xs-components-links-module-SharedModule-5a49dc75cc67d1539e88d8e844c18bd1"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-SharedModule-5a49dc75cc67d1539e88d8e844c18bd1"' :
                                            'id="xs-components-links-module-SharedModule-5a49dc75cc67d1539e88d8e844c18bd1"' }>
                                            <li class="link">
                                                <a href="components/AdminLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AdminLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BackToTopComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BackToTopComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterLogoComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterLogoComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderActionsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderActionsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderControlsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderControlsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MainLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MainLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotFoundComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotFoundComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/StateModule.html" data-type="entity-link">StateModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/StatisticsModule.html" data-type="entity-link">StatisticsModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-StatisticsModule-8c1fe4826207a06c59d079dd0c6dfeef"' : 'data-target="#xs-components-links-module-StatisticsModule-8c1fe4826207a06c59d079dd0c6dfeef"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-StatisticsModule-8c1fe4826207a06c59d079dd0c6dfeef"' :
                                            'id="xs-components-links-module-StatisticsModule-8c1fe4826207a06c59d079dd0c6dfeef"' }>
                                            <li class="link">
                                                <a href="components/AdminLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AdminLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BackToTopComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BackToTopComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterLogoComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterLogoComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderActionsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderActionsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderControlsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderControlsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderNavigationItemsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderNavigationItemsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoaderComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoaderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MainLayoutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MainLayoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotFoundComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotFoundComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-StatisticsModule-8c1fe4826207a06c59d079dd0c6dfeef"' : 'data-target="#xs-injectables-links-module-StatisticsModule-8c1fe4826207a06c59d079dd0c6dfeef"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-StatisticsModule-8c1fe4826207a06c59d079dd0c6dfeef"' :
                                        'id="xs-injectables-links-module-StatisticsModule-8c1fe4826207a06c59d079dd0c6dfeef"' }>
                                        <li class="link">
                                            <a href="injectables/StatisticsService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>StatisticsService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/StatisticsRoutingModule.html" data-type="entity-link">StatisticsRoutingModule</a>
                            </li>
                </ul>
                </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#components-links"' :
                            'data-target="#xs-components-links"' }>
                            <span class="icon ion-md-cog"></span>
                            <span>Components</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="components-links"' : 'id="xs-components-links"' }>
                            <li class="link">
                                <a href="components/AboutProjectComponent.html" data-type="entity-link">AboutProjectComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/AboutResourcesComponent.html" data-type="entity-link">AboutResourcesComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/AccordionComponent.html" data-type="entity-link">AccordionComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/BarChartComponent.html" data-type="entity-link">BarChartComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/BlogComponent.html" data-type="entity-link">BlogComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/BlogPostComponent.html" data-type="entity-link">BlogPostComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/ChartFiltersComponent.html" data-type="entity-link">ChartFiltersComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/DataContainerComponent.html" data-type="entity-link">DataContainerComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/DatasetsCategoryComponent.html" data-type="entity-link">DatasetsCategoryComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/DatasetsHeaderComponent.html" data-type="entity-link">DatasetsHeaderComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/FaqComponent.html" data-type="entity-link">FaqComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HeaderBarComponent.html" data-type="entity-link">HeaderBarComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeBannerComponent.html" data-type="entity-link">HomeBannerComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeComponent.html" data-type="entity-link">HomeComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeContactFormComponent.html" data-type="entity-link">HomeContactFormComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeFaqContactComponent.html" data-type="entity-link">HomeFaqContactComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeMobileAppComponent.html" data-type="entity-link">HomeMobileAppComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeNewsComponent.html" data-type="entity-link">HomeNewsComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeNewsMobileComponent.html" data-type="entity-link">HomeNewsMobileComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeSearchComponent.html" data-type="entity-link">HomeSearchComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/HomeYoutubeComponent.html" data-type="entity-link">HomeYoutubeComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/InstructionsComponent.html" data-type="entity-link">InstructionsComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/NewDataComponent.html" data-type="entity-link">NewDataComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/NewDataMobileComponent.html" data-type="entity-link">NewDataMobileComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/NewsComponent.html" data-type="entity-link">NewsComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/NewsPostComponent.html" data-type="entity-link">NewsPostComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/NewsTileComponent.html" data-type="entity-link">NewsTileComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/NewsTileMainComponent.html" data-type="entity-link">NewsTileMainComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/PageNavComponent.html" data-type="entity-link">PageNavComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/PageTemplateComponent.html" data-type="entity-link">PageTemplateComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/PaginationComponent.html" data-type="entity-link">PaginationComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/PartnersComponent.html" data-type="entity-link">PartnersComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/PieChartComponent.html" data-type="entity-link">PieChartComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/PostTileComponent.html" data-type="entity-link">PostTileComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/SectionTitleComponent.html" data-type="entity-link">SectionTitleComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/SocialComponent.html" data-type="entity-link">SocialComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/StatisticsComponent.html" data-type="entity-link">StatisticsComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/UIModalComponent.html" data-type="entity-link">UIModalComponent</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#directives-links"' :
                                'data-target="#xs-directives-links"' }>
                                <span class="icon ion-md-code-working"></span>
                                <span>Directives</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse " ${ isNormalMode ? 'id="directives-links"' : 'id="xs-directives-links"' }>
                                <li class="link">
                                    <a href="directives/DebounceKeyupDirective.html" data-type="entity-link">DebounceKeyupDirective</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#classes-links"' :
                            'data-target="#xs-classes-links"' }>
                            <span class="icon ion-ios-paper"></span>
                            <span>Classes</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="classes-links"' : 'id="xs-classes-links"' }>
                            <li class="link">
                                <a href="classes/DatasetsChangeViewMode.html" data-type="entity-link">DatasetsChangeViewMode</a>
                            </li>
                            <li class="link">
                                <a href="classes/HammerConfig.html" data-type="entity-link">HammerConfig</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#injectables-links"' :
                                'data-target="#xs-injectables-links"' }>
                                <span class="icon ion-md-arrow-round-down"></span>
                                <span>Injectables</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse " ${ isNormalMode ? 'id="injectables-links"' : 'id="xs-injectables-links"' }>
                                <li class="link">
                                    <a href="injectables/AppConfigService.html" data-type="entity-link">AppConfigService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/BlogService.html" data-type="entity-link">BlogService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/DatasetService.html" data-type="entity-link">DatasetService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/DatasetsService.html" data-type="entity-link">DatasetsService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/FAQService.html" data-type="entity-link">FAQService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/FontResizeService.html" data-type="entity-link">FontResizeService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/HomeService.html" data-type="entity-link">HomeService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/LanguageService.html" data-type="entity-link">LanguageService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/LoaderService.html" data-type="entity-link">LoaderService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/NewsService.html" data-type="entity-link">NewsService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/StatisticsService.html" data-type="entity-link">StatisticsService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/UIModalService.html" data-type="entity-link">UIModalService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/UtilsService.html" data-type="entity-link">UtilsService</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#interceptors-links"' :
                            'data-target="#xs-interceptors-links"' }>
                            <span class="icon ion-ios-swap"></span>
                            <span>Interceptors</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="interceptors-links"' : 'id="xs-interceptors-links"' }>
                            <li class="link">
                                <a href="interceptors/APIInterceptor.html" data-type="entity-link">APIInterceptor</a>
                            </li>
                            <li class="link">
                                <a href="interceptors/UniversalInterceptor.html" data-type="entity-link">UniversalInterceptor</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#interfaces-links"' :
                            'data-target="#xs-interfaces-links"' }>
                            <span class="icon ion-md-information-circle-outline"></span>
                            <span>Interfaces</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? ' id="interfaces-links"' : 'id="xs-interfaces-links"' }>
                            <li class="link">
                                <a href="interfaces/AppState.html" data-type="entity-link">AppState</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BlogArticle.html" data-type="entity-link">BlogArticle</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BlogData.html" data-type="entity-link">BlogData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/BlogTile.html" data-type="entity-link">BlogTile</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/DatasetsState.html" data-type="entity-link">DatasetsState</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/IBreadcrumbs.html" data-type="entity-link">IBreadcrumbs</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/IContactForm.html" data-type="entity-link">IContactForm</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/IFilterData.html" data-type="entity-link">IFilterData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/Ifilters.html" data-type="entity-link">Ifilters</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/IFiltersStructure.html" data-type="entity-link">IFiltersStructure</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/IsearchData.html" data-type="entity-link">IsearchData</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/Keyword.html" data-type="entity-link">Keyword</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/NavigationItem.html" data-type="entity-link">NavigationItem</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/NavigationItem-1.html" data-type="entity-link">NavigationItem</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/NewsArticle.html" data-type="entity-link">NewsArticle</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/NewsList.html" data-type="entity-link">NewsList</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/PaginationOffset.html" data-type="entity-link">PaginationOffset</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#miscellaneous-links"'
                            : 'data-target="#xs-miscellaneous-links"' }>
                            <span class="icon ion-ios-cube"></span>
                            <span>Miscellaneous</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="miscellaneous-links"' : 'id="xs-miscellaneous-links"' }>
                            <li class="link">
                                <a href="miscellaneous/enumerations.html" data-type="entity-link">Enums</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/functions.html" data-type="entity-link">Functions</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/typealiases.html" data-type="entity-link">Type aliases</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/variables.html" data-type="entity-link">Variables</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <a data-type="chapter-link" href="coverage.html"><span class="icon ion-ios-stats"></span>Documentation coverage</a>
                    </li>
                    <li class="divider"></li>
                    <li class="copyright">
                        Documentation generated using <a href="https://compodoc.app/" target="_blank">
                            <img data-src="images/compodoc-vectorise-inverted.png" class="img-responsive" data-type="compodoc-logo">
                        </a>
                    </li>
            </ul>
        </nav>
        `);
        this.innerHTML = tp.strings;
    }
});